﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Net;
using Nop.Core;
using System.Data.SqlClient;
using System.Text;

using Microsoft.Extensions.Primitives;
using Nop.Services.Media;
using Nop.Web.Models.Media;
using Microsoft.AspNetCore.Session;
using Nop.Core.Http.Extensions;
namespace Nop.Web.Controllers
{
    public class CustomBuilderController : Controller
    {
        SqlConnection con = new SqlConnection("data source=.; database=npbuilder; integrated security=SSPI;MultipleActiveResultSets=True");

        private readonly IPictureService _pictureService;
        private readonly IWebHelper _webHelper;

        public CustomBuilderController(IPictureService pictureService, IWebHelper webHelper)
        {
            this._pictureService = pictureService;
            this._webHelper = webHelper;
        }

        public IActionResult Index()
        {
            //Flag Product Variable

            string prdidflag = Request.Query["prdidflag"];
            string prdimgflag = Request.Query["prdimgflag"];
            string prdnameflag = Request.Query["prdnameflag"];
            string prdskuflag = Request.Query["prdskuflag"];
            //string prdpriceflag = Request.Query["prdpriceflag"];
            string prdpriceflag = "";

            //Flag Shaft Product Variable

            string prdidflagshaft = Request.Query["prdidflagshaft"];
            string prdimgflagshaft = Request.Query["prdimgflagshaft"];
            string prdnameflagshaft = Request.Query["prdnameflagshaft"];
            string prdskuflagshaft = Request.Query["prdskuflagshaft"];
            //string prdpriceflagshaft = Request.Query["prdpriceflagshaft"];
            string prdpriceflagshaft = "";

            //Quick Disconnect Product Variable

            string prdidqd = Request.Query["prdidqd"];
            string prdimgqd = Request.Query["prdimgqd"];
            string prdnameqd = Request.Query["prdnameqd"];
            string prdskuqd = Request.Query["prdskuqd"];
            //string prdpriceqd = Request.Query["prdpriceqd"];
            string prdpriceqd = "";

            //Mounting Bracket Product Variable

            string prdidmb = Request.Query["prdidmb"];
            string prdimgmb = Request.Query["prdimgmb"];
            string prdnamemb = Request.Query["prdnamemb"];
            string prdskumb = Request.Query["prdskumb"];
            //string prdpricemb = Request.Query["prdpricemb"];
            string prdpricemb = "";

            //Whip Lighting Product Variable

            string prdidwl = Request.Query["prdidwl"];
            string prdimgwl = Request.Query["prdimgwl"];
            string prdnamewl = Request.Query["prdnamewl"];
            string prdskuwl = Request.Query["prdskuwl"];
            //string prdpricewl = Request.Query["prdpricewl"];
            string prdpricewl = "";

            /* To set flag product from query string */

            if (prdidflag == null)
            {
                ViewBag.prdpriceflag = HttpContext.Session.GetString("prdpriceflag");
                if (HttpContext.Session.GetString("prdidflag") != null)
                {
                    ViewBag.prdidflag = HttpContext.Session.GetString("prdidflag");
                    ViewBag.prdimgflag = HttpContext.Session.GetString("prdimgflag");
                    ViewBag.prdnameflag = HttpContext.Session.GetString("prdnameflag");
                    ViewBag.prdskuflag = HttpContext.Session.GetString("prdskuflag");
                    ViewBag.resultattrflag = HttpContext.Session.GetString("resultattrflag");
                }
            }
            else
            {
               // con = new SqlConnection("data source=.; database=npbuilder; integrated security=SSPI;MultipleActiveResultSets=True");
                con.Open();
                SqlCommand prdprcflg = new SqlCommand("SELECT Price FROM Product WHERE Id =" + prdidflag, con);
                SqlDataReader prcflag = prdprcflg.ExecuteReader();
                prcflag.Read();
                var prdpricequeryold = String.Format("{0:0.00}", prcflag["Price"]);
                prdpriceflag = "$" + prdpricequeryold.ToString();

                HttpContext.Session.SetString("prdidflag", Convert.ToString(prdidflag));
                if (prdimgflag == null)
                {
                    HttpContext.Session.SetString("prdimgflag", " http://localhost:15536/images/thumbs/default-image_550.png");
                }
                else
                {
                    HttpContext.Session.SetString("prdimgflag", prdimgflag);
                }
                HttpContext.Session.SetString("prdnameflag", prdnameflag);
                if (prdskuflag != null)
                {
                    HttpContext.Session.SetString("prdskuflag", prdskuflag);
                }
                if(prdpriceflag != null)
                {
                     HttpContext.Session.SetString("prdpriceflag", prdpriceflag);
                }

                con = new SqlConnection("data source=.; database=npbuilder; integrated security=SSPI;MultipleActiveResultSets=True");
                con.Open();
                SqlCommand attrflag = new SqlCommand("SELECT Name FROM ProductAttributeValue INNER JOIN Product_ProductAttribute_Mapping " +
                    "ON ProductAttributeValue.ProductAttributeMappingId = Product_ProductAttribute_Mapping.Id " +
                    "WHERE Product_ProductAttribute_Mapping.ProductId ="  + prdidflag, con);
                SqlDataReader sdrflag = attrflag.ExecuteReader();
                   List<string> prdattflag = new List<string>();

                while (sdrflag.Read())
                {
                    prdattflag.Add(Convert.ToString(sdrflag["Name"]));
                }

                string resultattrflag = string.Join(",", prdattflag.Select(i => i.ToString()).ToArray());

                HttpContext.Session.SetString("resultattrflag", resultattrflag);

                // string prdattflag = "3/4\" Fully lit";
                //string[] prdattflag = { "3/4\" Fully lit", "1/2\" Tapered", "1/2\"" ,"3' x 5'" };

                ViewBag.prdidflag = HttpContext.Session.GetString("prdidflag");
                ViewBag.prdimgflag = HttpContext.Session.GetString("prdimgflag");
                ViewBag.prdnameflag = HttpContext.Session.GetString("prdnameflag");
                ViewBag.prdskuflag = HttpContext.Session.GetString("prdskuflag");
                ViewBag.prdpriceflag = HttpContext.Session.GetString("prdpriceflag");
                ViewBag.resultattrflag = HttpContext.Session.GetString("resultattrflag"); 

                con.Close();

            }

            /* To set flag shaft product from query string */

            if (prdidflagshaft == null)
            {
                ViewBag.prdpriceflagshaft = HttpContext.Session.GetString("prdpriceflagshaft");
                if (HttpContext.Session.GetString("prdidflagshaft") != null)
                {
                    ViewBag.prdidflagshaft = HttpContext.Session.GetString("prdidflagshaft");
                    ViewBag.prdimgflagshaft = HttpContext.Session.GetString("prdimgflagshaft");
                    ViewBag.prdnameflagshaft = HttpContext.Session.GetString("prdnameflagshaft");
                    ViewBag.prdskuflagshaft = HttpContext.Session.GetString("prdskuflagshaft");
                    ViewBag.resultattrflagshaft = HttpContext.Session.GetString("resultattrflagshaft");
                }

            } else
            {
                SqlConnection conflagshaft = null;
                conflagshaft = new SqlConnection("data source=.; database=npbuilder; integrated security=SSPI;MultipleActiveResultSets=True");
                conflagshaft.Open();
                SqlCommand prdprcflg = new SqlCommand("SELECT Price FROM Product WHERE Id =" + prdidflagshaft, conflagshaft);
                SqlDataReader prcflag = prdprcflg.ExecuteReader();
                prcflag.Read();
                var prdpricequeryold = String.Format("{0:0.00}", prcflag["Price"]);
                prdpriceflagshaft = "$" + prdpricequeryold.ToString();


                HttpContext.Session.SetString("prdidflagshaft", prdidflagshaft);
                if(prdimgflagshaft == null)
                {
                    HttpContext.Session.SetString("prdimgflagshaft", " http://localhost:15536/images/thumbs/default-image_550.png");
                }
                else
                {
                    HttpContext.Session.SetString("prdimgflagshaft", prdimgflagshaft);
                }
                HttpContext.Session.SetString("prdnameflagshaft", prdnameflagshaft);
                if (prdskuflagshaft != null)
                {
                    HttpContext.Session.SetString("prdskuflagshaft", prdskuflagshaft);
                }
                if(prdpriceflagshaft != null)
                {
                     HttpContext.Session.SetString("prdpriceflagshaft", prdpriceflagshaft);
                }

                SqlConnection con = null;
                con = new SqlConnection("data source=.; database=npbuilder; integrated security=SSPI;MultipleActiveResultSets=True");
                con.Open();
                SqlCommand attrflagshaft = new SqlCommand("SELECT Name FROM ProductAttributeValue INNER JOIN Product_ProductAttribute_Mapping " +
                    "ON ProductAttributeValue.ProductAttributeMappingId = Product_ProductAttribute_Mapping.Id " +
                    "WHERE Product_ProductAttribute_Mapping.ProductId =" + prdidflagshaft, con);
                SqlDataReader sdrflagshaft = attrflagshaft.ExecuteReader();
                List<string> prdattflagshaft = new List<string>();

                while (sdrflagshaft.Read())
                {
                    prdattflagshaft.Add(Convert.ToString(sdrflagshaft["Name"]));
                }

                string resultattrflagshaft = string.Join(",", prdattflagshaft.Select(i => i.ToString()).ToArray());

                HttpContext.Session.SetString("resultattrflagshaft", resultattrflagshaft);

                ViewBag.prdidflagshaft = HttpContext.Session.GetString("prdidflagshaft");
                ViewBag.prdimgflagshaft = HttpContext.Session.GetString("prdimgflagshaft");
                ViewBag.prdnameflagshaft = HttpContext.Session.GetString("prdnameflagshaft");
                ViewBag.prdskuflagshaft = HttpContext.Session.GetString("prdskuflagshaft");
                ViewBag.prdpriceflagshaft = HttpContext.Session.GetString("prdpriceflagshaft");
                ViewBag.resultattrflagshaft = HttpContext.Session.GetString("resultattrflagshaft");
            }

            /* To set Quick Disconnect product from query string */

            if (prdidqd == null)
            {
                ViewBag.prdpriceqd = HttpContext.Session.GetString("prdpriceqd");
                if (HttpContext.Session.GetString("prdidqd") != null)
                {
                    ViewBag.prdidqd = HttpContext.Session.GetString("prdidqd");
                    ViewBag.prdimgqd = HttpContext.Session.GetString("prdimgqd");
                    ViewBag.prdnameqd = HttpContext.Session.GetString("prdnameqd");
                    ViewBag.prdskuqd = HttpContext.Session.GetString("prdskuqd");
                }
            }
            else
            {
                SqlConnection conqd = null;
                conqd = new SqlConnection("data source=.; database=npbuilder; integrated security=SSPI;MultipleActiveResultSets=True");
                conqd.Open();
                SqlCommand prdprcflg = new SqlCommand("SELECT Price FROM Product WHERE Id =" + prdidqd, conqd);
                SqlDataReader prcflag = prdprcflg.ExecuteReader();
                prcflag.Read();
                var prdpricequeryold = String.Format("{0:0.00}", prcflag["Price"]);
                prdpriceqd = "$" + prdpricequeryold.ToString();


                HttpContext.Session.SetString("prdidqd", prdidqd);
                if(prdimgqd == null)
                {
                    HttpContext.Session.SetString("prdimgqd", " http://localhost:15536/images/thumbs/default-image_550.png");
                }
                else
                {
                    HttpContext.Session.SetString("prdimgqd", prdimgqd);
                }
                HttpContext.Session.SetString("prdnameqd", prdnameqd);
                if (prdskuqd != null)
                {
                    HttpContext.Session.SetString("prdskuqd", prdskuqd);
                }
                HttpContext.Session.SetString("prdpriceqd", prdpriceqd);

                ViewBag.prdidqd = HttpContext.Session.GetString("prdidqd");
                ViewBag.prdimgqd = HttpContext.Session.GetString("prdimgqd");
                ViewBag.prdnameqd = HttpContext.Session.GetString("prdnameqd");
                ViewBag.prdskuqd = HttpContext.Session.GetString("prdskuqd");
                ViewBag.prdpriceqd = HttpContext.Session.GetString("prdpriceqd");
            }

            /* To set Mouting Bracket Products from Query String */

            if(prdidmb == null)
            {
                ViewBag.prdpricemb = HttpContext.Session.GetString("prdpricemb");
                if (HttpContext.Session.GetString("prdidmb") != null)
                {
                    ViewBag.prdidmb = HttpContext.Session.GetString("prdidmb");
                    ViewBag.prdimgmb = HttpContext.Session.GetString("prdimgmb");
                    ViewBag.prdnamemb = HttpContext.Session.GetString("prdnamemb");
                    ViewBag.prdskumb = HttpContext.Session.GetString("prdskumb");
                }

            } else
            {
                SqlConnection conmb = null;
                conmb = new SqlConnection("data source=.; database=npbuilder; integrated security=SSPI;MultipleActiveResultSets=True");
                conmb.Open();
                SqlCommand prdprcflg = new SqlCommand("SELECT Price FROM Product WHERE Id =" + prdidmb, conmb);
                SqlDataReader prcflag = prdprcflg.ExecuteReader();
                prcflag.Read();
                var prdpricequeryold = String.Format("{0:0.00}", prcflag["Price"]);
                prdpricemb = "$" + prdpricequeryold.ToString();

                HttpContext.Session.SetString("prdidmb", prdidmb);
                if(prdimgmb == null)
                {
                    HttpContext.Session.SetString("prdimgmb", " http://localhost:15536/images/thumbs/default-image_550.png");
                }
                else
                {
                    HttpContext.Session.SetString("prdimgmb", prdimgmb);
                }
                HttpContext.Session.SetString("prdnamemb", prdnamemb);
                if (prdskumb != null)
                {
                    HttpContext.Session.SetString("prdskumb", prdskumb);
                }
                HttpContext.Session.SetString("prdpricemb", prdpricemb);

                ViewBag.prdidmb = HttpContext.Session.GetString("prdidmb");
                ViewBag.prdimgmb = HttpContext.Session.GetString("prdimgmb");
                ViewBag.prdnamemb = HttpContext.Session.GetString("prdnamemb");
                ViewBag.prdskumb = HttpContext.Session.GetString("prdskumb");
                ViewBag.prdpricemb = HttpContext.Session.GetString("prdpricemb");
            }

            /* To set Whip Lighting Products from Query String */

            if (prdidwl == null)
            {
                ViewBag.prdpricewl = HttpContext.Session.GetString("prdpricewl");
                if (HttpContext.Session.GetString("prdidwl") != null)
                {
                    ViewBag.prdidwl = HttpContext.Session.GetString("prdidwl");
                    ViewBag.prdimgwl = HttpContext.Session.GetString("prdimgwl");
                    ViewBag.prdnamewl = HttpContext.Session.GetString("prdnamewl");
                    ViewBag.prdskuwl = HttpContext.Session.GetString("prdskuwl");
                }

            } else
            {
                SqlConnection conwl = null;
                conwl = new SqlConnection("data source=.; database=npbuilder; integrated security=SSPI;MultipleActiveResultSets=True");
                conwl.Open();
                SqlCommand prdprcflg = new SqlCommand("SELECT Price FROM Product WHERE Id =" + prdidwl, conwl);
                SqlDataReader prcflag = prdprcflg.ExecuteReader();
                prcflag.Read();
                var prdpricequeryold = String.Format("{0:0.00}", prcflag["Price"]);
                prdpricewl = "$" + prdpricequeryold.ToString();

                HttpContext.Session.SetString("prdidwl", prdidwl);
                if(prdimgwl == null)
                {
                    HttpContext.Session.SetString("prdimgwl", " http://localhost:15536/images/thumbs/default-image_550.png");
                }
                else
                {
                    HttpContext.Session.SetString("prdimgwl", prdimgwl);
                }
                HttpContext.Session.SetString("prdnamewl", prdnamewl);
                HttpContext.Session.SetString("prdskuwl", prdskuwl);
                HttpContext.Session.SetString("prdpricewl", prdpricewl);

                ViewBag.prdidwl = HttpContext.Session.GetString("prdidwl");
                ViewBag.prdimgwl = HttpContext.Session.GetString("prdimgwl");
                ViewBag.prdnamewl = HttpContext.Session.GetString("prdnamewl");
                ViewBag.prdskuwl = HttpContext.Session.GetString("prdskuwl");
                ViewBag.prdpricewl = HttpContext.Session.GetString("prdpricewl");
            }

            /* cod for pro setup product load */



            return View();
        }

        /* Action for complete wheep product */

        public IActionResult Prddetil(int id)
        {
            SqlConnection con = null;
            con = new SqlConnection("data source=.; database=npbuilder; integrated security=SSPI;MultipleActiveResultSets=True");
            con.Open();

            /* For Flag product from complete wheep  */

            SqlCommand prddetailflag = new SqlCommand("SELECT Id,Name,Sku,Price FROM Product WhERE ParentGroupedProductId = " + id + "AND DisplayOrder = 1", con);
            SqlDataReader sdrdetailflag = prddetailflag.ExecuteReader();
            sdrdetailflag.Read();

            /* For product image */

            var prdid = sdrdetailflag["Id"];
            SqlCommand slugcmd = new SqlCommand("SELECT UrlRecord.Slug FROM UrlRecord INNER JOIN Product ON UrlRecord.EntityId = Product.Id WHERE Product.Id =" + prdid + " AND UrlRecord.EntityName = 'Product'", con);
            SqlDataReader slugsdr = slugcmd.ExecuteReader();
            slugsdr.Read();
            var seName = slugsdr["Slug"].ToString();
            SqlCommand picdcmd = new SqlCommand("SELECT id FROM Picture where SeoFilename = '" + seName + "'", con);
            SqlDataReader picidsdr = picdcmd.ExecuteReader();
            picidsdr.Read();
            var picture = _pictureService.GetPicturesByProductId(Convert.ToInt32(prdid)).FirstOrDefault();
            var prdimgquery = new StringBuilder();
            if (picture != null)
            {
                seName = slugsdr["Slug"].ToString();
                var pictureId = picidsdr["id"].ToString();
                var mimeType = "image/jpeg";

                prdimgquery.Append(_webHelper.GetStoreLocation());
                prdimgquery.Append("images/thumbs/");
                prdimgquery.Append(pictureId.ToString().PadLeft(7, '0'));
                prdimgquery.Append("_" + seName);
                prdimgquery.Append("." + mimeType.Replace("image/", ""));
            }

            /* For price */

            var prdpricequeryold = String.Format("{0:0.00}", sdrdetailflag["Price"]);

            string prdidflag = Convert.ToString(sdrdetailflag["Id"]);
            string prdimgflag = Convert.ToString(prdimgquery);
            string prdnameflag = Convert.ToString(sdrdetailflag["Name"]);
            string prdskuflag = Convert.ToString(sdrdetailflag["Sku"]); 
            string prdpriceflag = prdpricequeryold.ToString();

            if (prdimgflag == null)
            {
                HttpContext.Session.SetString("prdimgflag", " http://localhost:15536/images/thumbs/default-image_550.png");
            }
            else
            {
                HttpContext.Session.SetString("prdimgflag", prdimgflag);
            }
            HttpContext.Session.SetString("prdnameflag", prdnameflag);
            HttpContext.Session.SetString("prdskuflag", prdskuflag);
            if (prdpriceflag != null)
            {
                HttpContext.Session.SetString("prdpriceflag", prdpriceflag);
            }

            /* For flag shaft product from complete wheep */

            SqlCommand prddetailflagshaft = new SqlCommand("SELECT Id,Name,Sku,Price FROM Product WhERE ParentGroupedProductId = " + id + "AND DisplayOrder = 2", con);
            SqlDataReader sdrdetailflagshaft = prddetailflagshaft.ExecuteReader();
            sdrdetailflagshaft.Read();

            /* For product image */

            var prdidflagshaft = sdrdetailflagshaft["Id"];
            SqlCommand slugcmdflagshaft = new SqlCommand("SELECT UrlRecord.Slug FROM UrlRecord INNER JOIN Product ON UrlRecord.EntityId = Product.Id WHERE Product.Id =" + prdidflagshaft + " AND UrlRecord.EntityName = 'Product'", con);
            SqlDataReader slugsdrflagshaft = slugcmdflagshaft.ExecuteReader();
            slugsdrflagshaft.Read();
            var seNameflagshaft = slugsdrflagshaft["Slug"].ToString();
            SqlCommand picdcmdflagshaft = new SqlCommand("SELECT id FROM Picture where SeoFilename = '" + seNameflagshaft + "'", con);
            SqlDataReader picidsdrflagshaft = picdcmdflagshaft.ExecuteReader();
            picidsdrflagshaft.Read();
            picture = _pictureService.GetPicturesByProductId(Convert.ToInt32(prdidflagshaft)).FirstOrDefault();
            var prdimgqueryflagshaft = new StringBuilder();
            if (picture != null)
            {
                seName = slugsdrflagshaft["Slug"].ToString();
                var pictureId = picidsdrflagshaft["id"].ToString();
                var mimeType = "image/jpeg";

                prdimgqueryflagshaft.Append(_webHelper.GetStoreLocation());
                prdimgqueryflagshaft.Append("images/thumbs/");
                prdimgqueryflagshaft.Append(pictureId.ToString().PadLeft(7, '0'));
                prdimgqueryflagshaft.Append("_" + seName);
                prdimgqueryflagshaft.Append("." + mimeType.Replace("image/", ""));
            }

            /* For price */

            var prdpricequeryoldflagshaft = String.Format("{0:0.00}", sdrdetailflagshaft["Price"]);

            prdidflagshaft = Convert.ToString(sdrdetailflagshaft["Id"]);
            string prdimgflagshaft = Convert.ToString(prdimgqueryflagshaft);
            string prdnameflagshaft = Convert.ToString(sdrdetailflagshaft["Name"]);
            string prdskuflagshaft = Convert.ToString(sdrdetailflagshaft["Sku"]);
            //string prdpriceflagshaft = Request.Query["prdpriceflagshaft"];
            string prdpriceflagshaft = prdpricequeryoldflagshaft.ToString();


            HttpContext.Session.SetString("prdidflagshaft", Convert.ToString(sdrdetailflagshaft["Id"]));
            if (prdimgflagshaft == null)
            {
                HttpContext.Session.SetString("prdimgflagshaft", " http://localhost:15536/images/thumbs/default-image_550.png");
            }
            else
            {
                HttpContext.Session.SetString("prdimgflagshaft", prdimgflagshaft);
            }
            HttpContext.Session.SetString("prdnameflagshaft", prdnameflagshaft);
            HttpContext.Session.SetString("prdskuflagshaft", prdskuflagshaft);
            if (prdpriceflagshaft != null)
            {
                HttpContext.Session.SetString("prdpriceflagshaft", prdpriceflagshaft);
            }

            /* For Quick Disconnect product from complete wheep */

            SqlCommand prddetailqd = new SqlCommand("SELECT Id,Name,Sku,Price FROM Product WhERE ParentGroupedProductId = " + id + "AND DisplayOrder = 3", con);
            SqlDataReader sdrdetailqd = prddetailqd.ExecuteReader();
            sdrdetailqd.Read();

            /* For product image */

            var prdidqd = sdrdetailqd["Id"];
            SqlCommand slugcmdqd = new SqlCommand("SELECT UrlRecord.Slug FROM UrlRecord INNER JOIN Product ON UrlRecord.EntityId = Product.Id WHERE Product.Id =" + prdidqd + " AND UrlRecord.EntityName = 'Product'", con);
            SqlDataReader slugsdrqd = slugcmdqd.ExecuteReader();
            slugsdrqd.Read();
            var seNameqd = slugsdrqd["Slug"].ToString();
            SqlCommand picdcmdqd = new SqlCommand("SELECT id FROM Picture where SeoFilename = '" + seNameqd + "'", con);
            SqlDataReader picidsdrqd = picdcmdqd.ExecuteReader();
            picidsdrqd.Read();
            picture = _pictureService.GetPicturesByProductId(Convert.ToInt32(prdidqd)).FirstOrDefault();
            var prdimgqueryqd = new StringBuilder();
            if (picture != null)
            {
                seName = slugsdrqd["Slug"].ToString();
                var pictureId = picidsdrqd["id"].ToString();
                var mimeType = "image/jpeg";

                prdimgqueryqd.Append(_webHelper.GetStoreLocation());
                prdimgqueryqd.Append("images/thumbs/");
                prdimgqueryqd.Append(pictureId.ToString().PadLeft(7, '0'));
                prdimgqueryqd.Append("_" + seName);
                prdimgqueryqd.Append("." + mimeType.Replace("image/", ""));
            }

            /* For price */

            var prdpricequeryoldqd = String.Format("{0:0.00}", sdrdetailqd["Price"]);

            prdidqd = Convert.ToString(sdrdetailqd["Id"]);
            string prdimgqd = Convert.ToString(prdimgqueryqd);
            string prdnameqd = Convert.ToString(sdrdetailqd["Name"]);
            string prdskuqd = Convert.ToString(sdrdetailqd["Sku"]);
            string prdpriceqd = prdpricequeryoldqd.ToString();


            HttpContext.Session.SetString("prdidqd", Convert.ToString(sdrdetailqd["Id"]));
            if (prdimgqd == null)
            {
                HttpContext.Session.SetString("prdimgqd", " http://localhost:15536/images/thumbs/default-image_550.png");
            }
            else
            {
                HttpContext.Session.SetString("prdimgqd", prdimgqd);
            }
            HttpContext.Session.SetString("prdnameqd", prdnameqd);
            HttpContext.Session.SetString("prdskuqd", prdskuqd);
            if (prdpriceqd != null)
            {
                HttpContext.Session.SetString("prdpriceqd", prdpriceqd);
            }

            /* For Mouting Bracket product from complete wheep */

            string prdidmb = "";
            string prdimgmb = "";
            string prdnamemb = "";
            string prdskumb = "";
            string prdpricemb = "";

            SqlCommand prddetailmb = new SqlCommand("SELECT Id,Name,Sku,Price FROM Product WhERE ParentGroupedProductId = " + id + "AND DisplayOrder = 4", con);
            SqlDataReader sdrdetailmb = prddetailmb.ExecuteReader();

            if (sdrdetailmb.Read())
            {

                /* For product image */

                if (sdrdetailmb["Id"] != null)
                {

                    prdidmb = Convert.ToString(sdrdetailmb["Id"]);
                    SqlCommand slugcmdmb = new SqlCommand("SELECT UrlRecord.Slug FROM UrlRecord INNER JOIN Product ON UrlRecord.EntityId = Product.Id WHERE Product.Id =" + prdidmb + " AND UrlRecord.EntityName = 'Product'", con);
                    SqlDataReader slugsdrmb = slugcmdmb.ExecuteReader();
                    slugsdrmb.Read();
                    var seNamemb = slugsdrmb["Slug"].ToString();
                    SqlCommand picdcmdmb = new SqlCommand("SELECT id FROM Picture where SeoFilename = '" + seNamemb + "'", con);
                    SqlDataReader picidsdrmb = picdcmdmb.ExecuteReader();
                    picidsdrmb.Read();
                    picture = _pictureService.GetPicturesByProductId(Convert.ToInt32(prdidmb)).FirstOrDefault();
                    var prdimgquerymb = new StringBuilder();
                    if (picture != null)
                    {
                        seName = slugsdrmb["Slug"].ToString();
                        var pictureId = picidsdrmb["id"].ToString();
                        var mimeType = "image/jpeg";

                        prdimgquerymb.Append(_webHelper.GetStoreLocation());
                        prdimgquerymb.Append("images/thumbs/");
                        prdimgquerymb.Append(pictureId.ToString().PadLeft(7, '0'));
                        prdimgquerymb.Append("_" + seName);
                        prdimgquerymb.Append("." + mimeType.Replace("image/", ""));
                    }

                    /* For price */

                    var prdpricequeryoldmb = String.Format("{0:0.00}", sdrdetailmb["Price"]);

                    prdidmb = Convert.ToString(sdrdetailmb["Id"]);
                    prdimgmb = Convert.ToString(prdimgquerymb);
                    prdnamemb = Convert.ToString(sdrdetailmb["Name"]);
                    prdskumb = Convert.ToString(sdrdetailmb["Sku"]);
                    prdpricemb = prdpricequeryoldmb.ToString();


                    HttpContext.Session.SetString("prdidmb", Convert.ToString(sdrdetailmb["Id"]));
                    if (prdimgmb == null)
                    {
                        HttpContext.Session.SetString("prdimgmb", " http://localhost:15536/images/thumbs/default-image_550.png");
                    }
                    else
                    {
                        HttpContext.Session.SetString("prdimgmb", prdimgmb);
                    }
                    HttpContext.Session.SetString("prdnamemb", prdnamemb);
                    HttpContext.Session.SetString("prdskumb", prdskumb);
                    if (prdpricemb != null)
                    {
                        HttpContext.Session.SetString("prdpricemb", prdpricemb);
                    }
                }
            }


            /* For Whip Lighting product from complete wheep */

            string prdidwl = "";
            string prdimgwl = "";
            string prdnamewl = "";
            string prdskuwl = "";
            string prdpricewl = "";

            SqlCommand prddetailwl = new SqlCommand("SELECT Id,Name,Sku,Price FROM Product WhERE ParentGroupedProductId = " + id + "AND DisplayOrder = 5", con);
            SqlDataReader sdrdetailwl = prddetailwl.ExecuteReader();

            if (sdrdetailwl.Read())
            {

                /* For product image */

                prdidwl = Convert.ToString(sdrdetailwl["Id"]);
                SqlCommand slugcmdwl = new SqlCommand("SELECT UrlRecord.Slug FROM UrlRecord INNER JOIN Product ON UrlRecord.EntityId = Product.Id WHERE Product.Id =" + prdidwl + " AND UrlRecord.EntityName = 'Product'", con);
                SqlDataReader slugsdrwl = slugcmdwl.ExecuteReader();
                var prdimgquerywl = new StringBuilder();
                if (slugsdrwl.Read())
                {
                    var seNamewl = Convert.ToString(slugsdrwl["Slug"]);
                    SqlCommand picdcmdwl = new SqlCommand("SELECT id FROM Picture where SeoFilename = '" + seNamewl + "'", con);
                    SqlDataReader picidsdrwl = picdcmdwl.ExecuteReader();
                    if (picidsdrwl.Read())
                    {
                        picture = _pictureService.GetPicturesByProductId(Convert.ToInt32(prdidwl)).FirstOrDefault();
                        if (picture != null)
                        {
                            seName = Convert.ToString(slugsdrwl["Slug"]);
                            var pictureId = Convert.ToString(picidsdrwl["id"]);
                            var mimeType = "image/jpeg";

                            prdimgquerywl.Append(_webHelper.GetStoreLocation());
                            prdimgquerywl.Append("images/thumbs/");
                            prdimgquerywl.Append(pictureId.ToString().PadLeft(7, '0'));
                            prdimgquerywl.Append("_" + seName);
                            prdimgquerywl.Append("." + mimeType.Replace("image/", ""));
                            prdimgwl = Convert.ToString(prdimgquerywl);
                        }
                    }
                    else
                    {
                        prdimgwl = Convert.ToString("http://localhost:15536/images/thumbs/default-image_550.png");
                    }
                } else
                {
                    prdimgwl = Convert.ToString("http://localhost:15536/images/thumbs/default-image_550.png");
                }

                /* For price */

                var prdpricequeryoldwl = String.Format("{0:0.00}", sdrdetailwl["Price"]);

                prdidwl = Convert.ToString(sdrdetailwl["Id"]);
                prdnamewl = Convert.ToString(sdrdetailwl["Name"]);
                prdskuwl = Convert.ToString(sdrdetailwl["Sku"]);
                prdpricewl = Convert.ToString(prdpricequeryoldwl);

                if (prdidwl != null)
                {
                    HttpContext.Session.SetString("prdidwl", prdidwl);
                }

                if (prdimgwl == null)
                {
                    HttpContext.Session.SetString("prdimgwl", " http://localhost:15536/images/thumbs/default-image_550.png");
                }
                else
                {
                    HttpContext.Session.SetString("prdimgwl", prdimgwl);
                }
                HttpContext.Session.SetString("prdnamewl", prdnamewl);
                if (prdskuwl != null)
                {
                    HttpContext.Session.SetString("prdskuwl", prdskuwl);
                }
                if (prdpricewl != null)
                {
                    HttpContext.Session.SetString("prdpricewl", prdpricewl);
                }
            }






            return RedirectToAction("Index", "CustomBuilder", new { prdidflag = prdidflag, prdimgflag = prdimgflag, prdnameflag = prdnameflag, prdskuflag = prdskuflag, prdpriceflag = prdpriceflag,
                   prdidflagshaft = prdidflagshaft, prdimgflagshaft = prdimgflagshaft, prdnameflagshaft = prdnameflagshaft, prdskuflagshaft = prdskuflagshaft, prdpriceflagshaft = prdpriceflagshaft,
                   prdidqd = prdidqd, prdimgqd = prdimgqd, prdnameqd = prdnameqd, prdskuqd = prdskuqd, prdpriceqd = prdpriceqd,
                   prdidmb = prdidmb, prdimgmb = prdimgmb, prdnamemb = prdnamemb, prdskumb = prdskumb, prdpricemb = prdpricemb,
                   prdidwl = prdidwl, prdimgwl = prdimgwl, prdnamewl = prdnamewl, prdskuwl = prdskuwl, prdpricewl = prdpricewl });
        }


        public IActionResult MainPage()
        {
            return View();
        }

        public IActionResult Flag()
        {
            if (HttpContext.Session.GetString("prdidflag") != null)
            {
                HttpContext.Session.Remove("prdidflag");
                HttpContext.Session.Remove("prdimgflag");
                HttpContext.Session.Remove("prdnameflag");
                HttpContext.Session.Remove("prdskuflag");
                HttpContext.Session.SetString("prdpriceflag", "$0.00");
            }
            return RedirectToAction("Index", "CustomBuilder");
        }

        public IActionResult FlagShaft()
        {
            if (HttpContext.Session.GetString("prdidflagshaft") != null)
            {
                HttpContext.Session.Remove("prdidflagshaft");
                HttpContext.Session.Remove("prdimgflagshaft");
                HttpContext.Session.Remove("prdnameflagshaft");
                HttpContext.Session.Remove("prdskuflagshaft");
                HttpContext.Session.SetString("prdpriceflagshaft", "$0.00");
            }
            return RedirectToAction("Index", "CustomBuilder");
        }

        public IActionResult Quickdis()
        {
            if (HttpContext.Session.GetString("prdidqd") != null)
            {
                HttpContext.Session.Remove("prdidqd");
                HttpContext.Session.Remove("prdimgqd");
                HttpContext.Session.Remove("prdnameqd");
                HttpContext.Session.Remove("prdskuqd");
                HttpContext.Session.SetString("prdpriceqd", "$0.00");
            }
            return RedirectToAction("Index", "CustomBuilder");
        }

        public IActionResult Mountingbr()
        {
            if (HttpContext.Session.GetString("prdidmb") != null)
            {
                HttpContext.Session.Remove("prdidmb");
                HttpContext.Session.Remove("prdimgmb");
                HttpContext.Session.Remove("prdnamemb");
                HttpContext.Session.Remove("prdskumb");
                HttpContext.Session.SetString("prdpricemb", "$0.00");
            }
            return RedirectToAction("Index", "CustomBuilder");
        }

        public IActionResult Whiplight()
        {
            if (HttpContext.Session.GetString("prdidwl") != null)
            {
                HttpContext.Session.Remove("prdidwl");
                HttpContext.Session.Remove("prdimgwl");
                HttpContext.Session.Remove("prdnamewl");
                HttpContext.Session.Remove("prdskuwl");
                HttpContext.Session.SetString("prdpricewl", "$0.00");
            }

            return RedirectToAction("Index", "CustomBuilder");
        }

        public IActionResult ClearBuilder()
        {
            if(HttpContext.Session.GetString("prdidflag") != null)
            {
                HttpContext.Session.Remove("prdidflag");
                HttpContext.Session.Remove("prdimgflag");
                HttpContext.Session.Remove("prdnameflag");
                HttpContext.Session.Remove("prdskuflag");
                HttpContext.Session.SetString("prdpriceflag", "$0.00");
            }

            if (HttpContext.Session.GetString("prdidflagshaft") != null)
            {
                HttpContext.Session.Remove("prdidflagshaft");
                HttpContext.Session.Remove("prdimgflagshaft");
                HttpContext.Session.Remove("prdnameflagshaft");
                HttpContext.Session.Remove("prdskuflagshaft");
                HttpContext.Session.SetString("prdpriceflagshaft", "$0.00");
            }

            if (HttpContext.Session.GetString("prdidqd") != null)
            {
                HttpContext.Session.Remove("prdidqd");
                HttpContext.Session.Remove("prdimgqd");
                HttpContext.Session.Remove("prdnameqd");
                HttpContext.Session.Remove("prdskuqd");
                HttpContext.Session.SetString("prdpriceqd", "$0.00");
            }
            if (HttpContext.Session.GetString("prdidmb") != null)
            {
                HttpContext.Session.Remove("prdidmb");
                HttpContext.Session.Remove("prdimgmb");
                HttpContext.Session.Remove("prdnamemb");
                HttpContext.Session.Remove("prdskumb");
                HttpContext.Session.SetString("prdpricemb", "$0.00");
            }
            if (HttpContext.Session.GetString("prdidwl") != null)
            {
                HttpContext.Session.Remove("prdidwl");
                HttpContext.Session.Remove("prdimgwl");
                HttpContext.Session.Remove("prdnamewl");
                HttpContext.Session.Remove("prdskuwl");
                HttpContext.Session.SetString("prdpricewl", "$0.00");
            }

            return RedirectToAction("Index", "CustomBuilder");
        }
    }
}